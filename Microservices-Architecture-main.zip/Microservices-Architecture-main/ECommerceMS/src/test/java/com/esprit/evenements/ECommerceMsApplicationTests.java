package com.esprit.evenements;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceMsApplicationTests {

	@Test
	void contextLoads() {
	}

}

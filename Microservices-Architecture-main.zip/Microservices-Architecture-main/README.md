Projet Des Microservices:

    . Commande: Spring Boot & H2 Database
    
    . User: Spring Boot & H2 Database
  
    . Product: Spring Boot & H2 Database
    
    . Evenement: Spring Boot & H2 Database
    
    . Wishlist: NodeJs & Mongo Database
    
    . Zuul-server : Gateway (Proxy) pour la configuration des routes des micro-services
    
    . Eureka-server : Le serveur de découverte Eureka pour la découverte de tous les micro-services
    
    . Config-server : le serveur de configuration
  
How To Run:

    . Compiler les JAR de chaque microservice (mvn clean install) pour eviter les bugs utiliser JDK11
    
    . Lancer (docker-compose up)

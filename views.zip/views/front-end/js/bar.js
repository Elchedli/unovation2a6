function sendserver(){
    need.nom.value = rech.contenu.value;
    need.categorie.value = $("#cat").val();
    $( "#check" ).trigger("click");
}


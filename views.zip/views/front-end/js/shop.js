$(document).ready(function(){
    $('.sorting').on('change',function(){
        var categorie = "<?php echo $cata; ?>"; 
        var nom = "<?php echo $cata; ?>";

    });
});
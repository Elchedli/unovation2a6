<?php
require_once "../../basepdo.php";
require 'db.classe.php';
require 'panier.classe.php';
$DB = new DB();
$panier =new panier();

?>
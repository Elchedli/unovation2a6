<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="assets/css/produit.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="inputbox">
        <input type="text" name="name" autocomplete="off" required>
        <label for="name" class="label-name">
            <span class="content-name">Name</span>
        </label>
    </div>
</body>
</html>